class MatchData
  Backports.alias_method self, :==, :eql?
end