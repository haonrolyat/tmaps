class Numeric
  Backports.make_block_optional self, :step, :test_on => 42, :arg => [100, 6]
end