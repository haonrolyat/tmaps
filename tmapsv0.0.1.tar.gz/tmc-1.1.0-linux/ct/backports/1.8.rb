# require this file to load all the backports of the Ruby 1.8.x line

require File.expand_path(File.dirname(__FILE__) + "/tools")
Backports.require_relative "1.8.8"
