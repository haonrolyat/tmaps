#!/bin/sh

cd tmc
./tmc
